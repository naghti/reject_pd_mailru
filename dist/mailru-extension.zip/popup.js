"use strict";
(() => {
  // extension/readiness.ts
  function manualReasons(letter) {
    return [
      ...letter.missing.map((field) => `\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435: ${field}`),
      ...letter.actions
    ];
  }
  function readyLetters(letters) {
    return letters.filter((letter) => manualReasons(letter).length === 0);
  }

  // src/generated/data.json
  var data_default = {
    companies: [
      {
        id: "5a282799e3e5",
        name: "\u041C\u0422\u0421",
        emails: [
          "privacy@mts.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u041C\u0422\u0421\xBB",
        inn: "7740000076",
        ogrn: "1027700149124"
      },
      {
        id: "4a4f5f0c3bc8",
        name: "\u041E\u041A\u041A\u041E",
        emails: [
          "mail@okko.tv"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u041E\u043A\u043A\u043E\xBB",
        inn: "7814665871",
        ogrn: "1167847381130"
      },
      {
        id: "e47da5c37812",
        name: "\u0417\u043E\u043B\u043E\u0442\u043E\u0435 \u042F\u0431\u043B\u043E\u043A\u043E",
        emails: [
          "order@goldapple.ru",
          "CTD@goldapple.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0431\u0443\u0440\u0433 \u042F\u0431\u043B\u043E\u043A\u043E\xBB",
        inn: "6670381056",
        ogrn: "1126670019585"
      },
      {
        id: "1b2d16c4e3db",
        name: "\u0421\u0431\u0435\u0440 \u041C\u043E\u0431\u0430\u0439\u043B",
        emails: [
          "privacy@sberbank-tele.com"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: '\u0412 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u043C \u043F\u0438\u0441\u044C\u043C\u0435 \u043F\u0440\u043E\u043F\u0438\u0441\u0430\u0442\u044C: "\u0412 \u043F\u0443\u043D\u043A\u0442\u0435 11 \u0417\u0430\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u041F\u041E\u041B\u0418\u0422\u0418\u041A\u0418 \u0432 \u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u0432 \u041E\u041E\u041E \xAB\u0421\u0431\u0435\u0440\u0431\u0430\u043D\u043A-\u0422\u0435\u043B\u0435\u043A\u043E\u043C\xBB \u0432 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u0443\u043A\u0430\u0437\u0430\u043D\u044B \u0434\u0432\u0430 \u0432\u0438\u0434\u0430 \u0441\u0432\u044F\u0437\u0438, \u0430 \u0438\u043C\u0435\u043D\u043D\u043E: \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430 \u0438 \u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0439 \u0430\u0434\u0440\u0435\u0441.\n\n\xAB\u041B\u044E\u0431\u044B\u0435 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F, \u043A\u0430\u0441\u0430\u044E\u0449\u0438\u0435\u0441\u044F \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u041F\u0414\u043D, \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u041E\u0431\u0449\u0435\u0441\u0442\u0432\u0443 \u043D\u0430 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0443\u044E \u043F\u043E\u0447\u0442\u0443: privacy@sberbank-tele.com, \u043B\u0438\u0431\u043E \u043D\u0430 \u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0439 \u0430\u0434\u0440\u0435\u0441: 117997, \u0433. \u041C\u043E\u0441\u043A\u0432\u0430, \u0443\u043B. \u0412\u0430\u0432\u0438\u043B\u043E\u0432\u0430, \u0434. 19\xBB.\n\n\u041F\u0440\u043E\u0448\u0443 \u0440\u0430\u0441\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u043C\u043E\u0451 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u0435 \u0432 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u043C \u0432\u0438\u0434\u0435".   \u041A \u043F\u0438\u0441\u044C\u043C\u0443 \u043F\u0440\u0438\u043B\u043E\u0436\u0438\u0442\u044C PDF \u0444\u0430\u0439\u043B \u0441 \u043E\u0442\u0437\u044B\u0432\u043E\u043C \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F.',
        special: "pdf",
        withdrawalExtra: "\u0412 \u043F\u0443\u043D\u043A\u0442\u0435 11 \u0417\u0430\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u041F\u041E\u041B\u0418\u0422\u0418\u041A\u0418 \u0432 \u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u0432 \u041E\u041E\u041E \xAB\u0421\u0431\u0435\u0440\u0431\u0430\u043D\u043A-\u0422\u0435\u043B\u0435\u043A\u043E\u043C\xBB \u0432 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u0443\u043A\u0430\u0437\u0430\u043D\u044B \u0434\u0432\u0430 \u0432\u0438\u0434\u0430 \u0441\u0432\u044F\u0437\u0438, \u0430 \u0438\u043C\u0435\u043D\u043D\u043E: \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430 \u0438 \u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0439 \u0430\u0434\u0440\u0435\u0441.\n\n\xAB\u041B\u044E\u0431\u044B\u0435 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F, \u043A\u0430\u0441\u0430\u044E\u0449\u0438\u0435\u0441\u044F \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u041F\u0414\u043D, \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u041E\u0431\u0449\u0435\u0441\u0442\u0432\u0443 \u043D\u0430 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0443\u044E \u043F\u043E\u0447\u0442\u0443: privacy@sberbank-tele.com, \u043B\u0438\u0431\u043E \u043D\u0430 \u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0439 \u0430\u0434\u0440\u0435\u0441: 117997, \u0433. \u041C\u043E\u0441\u043A\u0432\u0430, \u0443\u043B. \u0412\u0430\u0432\u0438\u043B\u043E\u0432\u0430, \u0434. 19\xBB.\n\n\u041F\u0440\u043E\u0448\u0443 \u0440\u0430\u0441\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u043C\u043E\u0451 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u0435 \u0432 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u043C \u0432\u0438\u0434\u0435",
        legalName: "\u041E\u041E\u041E \xAB\u0421\u0431\u0435\u0440\u0431\u0430\u043D\u043A-\u0422\u0435\u043B\u0435\u043A\u043E\u043C\xBB",
        inn: "7736264044",
        ogrn: "1167746305430"
      },
      {
        id: "9b818ab53240",
        name: "\u0411\u0438\u0417\u043E\u043D",
        emails: [
          "info@bi.zone"
        ],
        sourceStatus: "\u041D\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u0430, \u0437\u0430\u043F\u0440\u043E\u0441 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0411\u0418\u0417\u041E\u041D\xBB",
        inn: "9701036178",
        ogrn: "1167746317210"
      },
      {
        id: "acda9a9c5fb4",
        name: "\u0411\u0438\u043B\u0430\u0439\u043D",
        emails: [
          "otvet@beeline.ru"
        ],
        sourceStatus: "\u041D\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u0430, \u0437\u0430\u043F\u0440\u043E\u0441 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u0412\u044B\u043C\u043F\u0435\u043B\u041A\u043E\u043C\xBB",
        inn: "7713076301",
        ogrn: "1027700166636"
      },
      {
        id: "37df0db92f3a",
        name: "\u0421\u0414\u042D\u041A",
        emails: [
          "cdek_rabota@cdek.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0421\u0414\u042D\u041A-\u0413\u043B\u043E\u0431\u0430\u043B\xBB",
        inn: "7722327689",
        ogrn: "1157746448463"
      },
      {
        id: "85099762b60b",
        name: "\u0422\u0435\u043D\u0437\u043E\u0440",
        emails: [
          "tensor@tensor.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u041A\u043E\u043C\u043F\u0430\u043D\u0438\u044F \xAB\u0422\u0435\u043D\u0437\u043E\u0440\xBB",
        inn: "7605016030",
        ogrn: "1027600787994"
      },
      {
        id: "2dd67355ac40",
        name: "\u0422\u0430\u043A\u0441\u043A\u043E\u043C",
        emails: [
          "taxcom@taxcom.ru"
        ],
        sourceStatus: "\u041D\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u0430, \u0437\u0430\u043F\u0440\u043E\u0441 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0422\u0430\u043A\u0441\u043A\u043E\u043C\xBB",
        inn: "7704211201",
        ogrn: "1027700071530"
      },
      {
        id: "204ddb8a15ea",
        name: "\u0422\u043E\u0447\u043A\u0430 \u0411\u0430\u043D\u043A",
        emails: [
          "tochka@tochka.com"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0411\u0410\u041D\u041A \u0422\u041E\u0427\u041A\u0410\xBB",
        inn: "9705120864",
        ogrn: "1187746637143"
      },
      {
        id: "d6e05ed3eb65",
        name: "\u041C\u0430\u0433\u043D\u0438\u0442",
        emails: [
          "info@magnit.ru"
        ],
        sourceStatus: "\u041D\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u0430, \u0437\u0430\u043F\u0440\u043E\u0441 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u041C\u0430\u0433\u043D\u0438\u0442\xBB",
        inn: "2309085638",
        ogrn: "1032304945947"
      },
      {
        id: "784090cbcdf0",
        name: "\u041A\u0443\u043F\u0435\u0440",
        emails: [
          "kuper@kuper.ru",
          "hello@kuper.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0418\u043D\u0441\u0442\u0430\u043C\u0430\u0440\u0442 \u0421\u0435\u0440\u0432\u0438\u0441\xBB",
        inn: "9705118142",
        ogrn: "1187746494980"
      },
      {
        id: "bf0d255c8484",
        name: "\u041B\u0443\u0447\u0438",
        emails: [
          "privacy@luchi.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u041B\u0443\u0447\u0438 \u0417\u0434\u043E\u0440\u043E\u0432\u044C\u0435\xBB",
        inn: "7106021081",
        ogrn: "1157154006767"
      },
      {
        id: "183e7e526673",
        name: "\u0421\u0417 \u041F\u0418\u041A",
        emails: [
          "info@pik.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u041F\u0418\u041A \u0421\u0417\xBB",
        inn: "7713011336",
        ogrn: "1027739137084"
      },
      {
        id: "44327d5e3d30",
        name: "\u0414\u0418\u0414\u0416\u0418 \u0422\u0415\u0425",
        emails: [
          "sales@digitech.ru"
        ],
        sourceStatus: "\u041D\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u0430, \u0437\u0430\u043F\u0440\u043E\u0441 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0414\u0418\u0414\u0416\u0418 \u0422\u0415\u0425\xBB",
        inn: "6679126050",
        ogrn: "1196658045055"
      },
      {
        id: "8035f16c937b",
        name: "\u0421\u0430\u043C\u043E\u043A\u0430\u0442",
        emails: [
          "dpo@samokat.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0423\u043C\u043D\u044B\u0439 \u0440\u0438\u0442\u0435\u0439\u043B\xBB",
        inn: "7811554010",
        ogrn: "1137847232852"
      },
      {
        id: "67a9b1e7bda3",
        name: "\u0413\u041A \u0410\u0441\u0442\u0440\u0430",
        emails: [
          "legal@astralinux.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0420\u0443\u0441\u0411\u0418\u0422\u0435\u0445-\u0410\u0441\u0442\u0440\u0430\xBB",
        inn: "7726388700",
        ogrn: "5167746207459"
      },
      {
        id: "dbd27579debe",
        name: "\u0421\u0417 \u0421\u0430\u043C\u043E\u043B\u0435\u0442",
        emails: [
          "request_pdn@samolet.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u0413\u041A \xAB\u0421\u0430\u043C\u043E\u043B\u0435\u0442\xBB",
        inn: "9731004688",
        ogrn: "1187746590283"
      },
      {
        id: "256425cd2755",
        name: "\u0411\u0430\u043D\u043A \u0414\u043E\u043C.\u0420\u0424",
        emails: [
          "info.bank@domrf.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u0411\u0430\u043D\u043A \u0414\u041E\u041C.\u0420\u0424\xBB",
        inn: "7725038124",
        ogrn: "1037739527077"
      },
      {
        id: "ecfab97afc0e",
        name: "\u0420\u0435\u043D\u0435\u0441\u0441\u0430\u043D\u0441 \u0411\u0430\u043D\u043A",
        emails: [
          "consultant@rencredit.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041A\u0411 \xAB\u0420\u0435\u043D\u0435\u0441\u0441\u0430\u043D\u0441 \u041A\u0440\u0435\u0434\u0438\u0442\xBB (\u041E\u041E\u041E)",
        inn: "7744000126",
        ogrn: "1027739586291"
      },
      {
        id: "075c8ff89799",
        name: "\u041B\u0430\u043C\u043E\u0434\u0430",
        emails: [
          "help@lamoda.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u041A\u0443\u043F\u0438\u0448\u0443\u0437\xBB",
        inn: "7705935687",
        ogrn: "5107746007628"
      },
      {
        id: "d13adb34b27c",
        name: "\u0421\u041A\u0411 \u041A\u043E\u043D\u0442\u0443\u0440",
        emails: [
          "info@skbkontur.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "\u041F\u0440\u043E\u0441\u044F\u0442 \u0440\u0443\u0447\u043D\u0443\u044E \u043F\u043E\u0434\u043F\u0438\u0441\u044C. \u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u0440\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u0433\u043E\u0442\u043E\u0432\u044B\u0439 \u0431\u043B\u0430\u043D\u043A \u0438 \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u043E\u0442 \u0440\u0443\u043A\u0438.",
        special: "signature",
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u041F\u0424 \u0421\u041A\u0411 \u041A\u043E\u043D\u0442\u0443\u0440\xBB",
        inn: "6663003127",
        ogrn: "1026605606620"
      },
      {
        id: "e363466a89ca",
        name: "\u0421\u043E\u043A\u043E\u043B\u043E\u0432",
        emails: [
          "pdn@svretail.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0421\u0412 \u0420\u0438\u0442\u0435\u0439\u043B\xBB",
        inn: "7716918034",
        ogrn: "1187746709677"
      },
      {
        id: "6cfdaac7b52a",
        name: "\u041B\u0430\u043D\u0438\u0442",
        emails: [
          "lanit@lanit.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u041B\u0410\u041D\u0418\u0422\xBB",
        inn: "7727004113",
        ogrn: "1027739031572"
      },
      {
        id: "97aaf5fdf152",
        name: "\u0420\u043E\u0441\u0442\u0435\u043B\u0435\u043A\u043E\u043C",
        emails: [
          "rostelecom@rt.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u0420\u043E\u0441\u0442\u0435\u043B\u0435\u043A\u043E\u043C\xBB",
        inn: "7707049388",
        ogrn: "1027700198767"
      },
      {
        id: "51d96642af56",
        name: "\u0421\u0431\u0435\u0440\u0422\u0440\u043E\u0439\u043A\u0430",
        emails: [
          "info@sbertroika.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0421\u0431\u0435\u0440\u0422\u0440\u043E\u0439\u043A\u0430\xBB",
        inn: "9702027017",
        ogrn: "1207700477820"
      },
      {
        id: "1c737c6ba00d",
        name: "\u0421\u0431\u0435\u0440",
        emails: [
          "Vopros_HR@sberbank.ru"
        ],
        sourceStatus: "\u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u041F\u0414 \u0443\u0434\u0430\u043B\u0435\u043D\u044B",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u0421\u0431\u0435\u0440\u0431\u0430\u043D\u043A \u0420\u043E\u0441\u0441\u0438\u0438\xBB",
        inn: "7707083893",
        ogrn: "1027700132195"
      },
      {
        id: "a8fb5d5d06c9",
        name: "\u0410\u041E \xAB\u0411\u0410\u0420\u0421 \u0413\u0440\u0443\u043F\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u0411\u0410\u0420\u0421 \u0413\u0440\u0443\u043F\xBB",
        inn: "1655251590",
        ogrn: "1121690063923",
        emails: [
          "bars@bars.group"
        ]
      },
      {
        id: "fac3c205270d",
        name: "\u0410\u041E \xAB\u0410\u0439\u0441\u043E\u0440\u0441\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u0410\u0439\u0441\u043E\u0440\u0441\xBB",
        inn: "9706009675",
        ogrn: "1207700393977",
        emails: [
          "support@isource.ru"
        ]
      },
      {
        id: "0fb2ea150de4",
        name: "\u041F\u0410\u041E \xAB\u0421\u043E\u0444\u0442\u043B\u0430\u0439\u043D\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u0421\u043E\u0444\u0442\u043B\u0430\u0439\u043D\xBB",
        inn: "7736227885",
        ogrn: "1027736009333",
        emails: [
          "info@softline.ru"
        ]
      },
      {
        id: "93d11b902057",
        name: "\xAB\u041D\u043E\u0432\u044B\u0439 \u0410\u0439 \u0422\u0438 \u041F\u0440\u043E\u0435\u043A\u0442\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\xAB\u041D\u043E\u0432\u044B\u0439 \u0410\u0439 \u0422\u0438 \u041F\u0440\u043E\u0435\u043A\u0442\xBB",
        inn: "7724338125",
        ogrn: "1157746958830",
        emails: [
          "3L@3L.ru",
          "rma@3L.ru"
        ]
      },
      {
        id: "102dfee06312",
        name: "\u041E\u041E\u041E \xAB\u041E\u0431\u043B\u0430\u0447\u043D\u044B\u0435 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u041E\u0431\u043B\u0430\u0447\u043D\u044B\u0435 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        inn: "7736279160",
        ogrn: "5167746080057",
        emails: [
          "security@cloud.ru"
        ]
      },
      {
        id: "d659759d7c9b",
        name: "\u0410\u041E \xAB\u041B\u0430\u0431\u043E\u0440\u0430\u0442\u043E\u0440\u0438\u044F \u041A\u0430\u0441\u043F\u0435\u0440\u0441\u043A\u043E\u0433\u043E\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u041B\u0430\u0431\u043E\u0440\u0430\u0442\u043E\u0440\u0438\u044F \u041A\u0430\u0441\u043F\u0435\u0440\u0441\u043A\u043E\u0433\u043E\xBB",
        inn: "7713140469",
        ogrn: "1027739867473",
        emails: [
          "info@kaspersky.com"
        ]
      },
      {
        id: "7c9eb642f593",
        name: "\u041E\u041E\u041E \xAB\u0420\u0443\u0431\u0438\u0442\u0435\u0445\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0420\u0443\u0431\u0438\u0442\u0435\u0445\xBB",
        inn: "7702404085",
        ogrn: "1167746693784",
        emails: [
          "info@rubytech.ru"
        ]
      },
      {
        id: "f85211ee5736",
        name: "\u0410\u041E \xAB\u0422\u0411\u0430\u043D\u043A\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u0422\u0411\u0430\u043D\u043A\xBB",
        inn: "7710140679",
        ogrn: "1027739642281",
        emails: [
          "deposit@tbank.ru"
        ]
      },
      {
        id: "5dda21bcc380",
        name: "\u0410\u041E \xAB\u0410\u0439-\u0422\u0435\u043A\u043E\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u0410\u0439-\u0422\u0435\u043A\u043E\xBB",
        inn: "7704160892",
        ogrn: "1027700031061",
        emails: [
          "income@i-teco.ru"
        ]
      },
      {
        id: "302886347af0",
        name: "\xAB\u0418\u0422 \u0418\u041A\u0421 5 \u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\xAB\u0418\u0422 \u0418\u041A\u0421 5 \u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        inn: "1615014289",
        ogrn: "1181690101911",
        emails: [
          "pdn@x5.ru"
        ]
      },
      {
        id: "a9e445367d12",
        name: "\u041E\u041E\u041E \xAB\u041B\u0423\u041A\u041E\u0419\u041B-\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u041B\u0423\u041A\u041E\u0419\u041B-\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        inn: "9709038314",
        ogrn: "1187746909129",
        emails: [
          "luktech@lukoil.com"
        ]
      },
      {
        id: "b9edc839a2ae",
        name: "\u041F\u0410\u041E \xAB\u0411\u0410\u041D\u041A \u0423\u0420\u0410\u041B\u0421\u0418\u0411\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u0411\u0410\u041D\u041A \u0423\u0420\u0410\u041B\u0421\u0418\u0411\xBB",
        inn: "0274062111",
        ogrn: "1020280000190",
        emails: [
          "infsec@uralsib.ru"
        ]
      },
      {
        id: "cd7faa2d1d77",
        name: "\u041F\u0410\u041E \xAB\u041C\u0422\u0421-\u0411\u0430\u043D\u043A\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u041C\u0422\u0421-\u0411\u0430\u043D\u043A\xBB",
        inn: "7702045051",
        ogrn: "1027739053704",
        emails: [
          "info@mtsbank.ru"
        ]
      },
      {
        id: "64f89a333338",
        name: "\u041E\u041E\u041E \xAB\u0410\u0432\u0438\u0442\u043E \u0422\u0435\u0445\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0410\u0432\u0438\u0442\u043E \u0422\u0435\u0445\xBB",
        inn: "9710089440",
        ogrn: "1217700216403",
        emails: [
          "tech@avito.ru"
        ]
      },
      {
        id: "87387cbbf569",
        name: "\u0410\u041E \xAB\u0420\u043E\u0441\u0441\u0435\u043B\u044C\u0445\u043E\u0437\u0431\u0430\u043D\u043A\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u0420\u043E\u0441\u0441\u0435\u043B\u044C\u0445\u043E\u0437\u0431\u0430\u043D\u043A\xBB",
        inn: "7725114488",
        ogrn: "1027700342890",
        emails: [
          "office@rshb.ru"
        ]
      },
      {
        id: "a339794270f5",
        name: "\xAB\u0412\u041A \u0426\u0438\u0444\u0440\u043E\u0432\u044B\u0435 \u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\xAB\u0412\u041A \u0426\u0438\u0444\u0440\u043E\u0432\u044B\u0435 \u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        inn: "7714415613",
        ogrn: "5177746017158",
        emails: [
          "digital.tech@corp.mail.ru"
        ]
      },
      {
        id: "6505b3009112",
        name: "\u041E\u041E\u041E \xAB\u041B\u041E\u0426\u0418\u042F\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u041B\u041E\u0426\u0418\u042F\xBB",
        inn: "9731028047",
        ogrn: "1197746102388",
        emails: [
          "cs@loodsen.ru"
        ]
      },
      {
        id: "4dd283e53237",
        name: "\u041E\u041E\u041E \xAB\u0410\u0440\u0435\u043D\u0430\u0434\u0430\u0442\u0430 \u0421\u043E\u0444\u0442\u0432\u0435\u0440\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0410\u0440\u0435\u043D\u0430\u0434\u0430\u0442\u0430 \u0421\u043E\u0444\u0442\u0432\u0435\u0440\xBB",
        inn: "7713468845",
        ogrn: "1197746413160",
        emails: [
          "info@arenadata.io"
        ]
      },
      {
        id: "2c4b0ea41284",
        name: "\xAB\u0413\u041A \xAB\u0418\u043D\u043D\u043E\u0442\u0435\u0445\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\xAB\u0413\u041A \xAB\u0418\u043D\u043D\u043E\u0442\u0435\u0445\xBB",
        inn: "9703073496",
        ogrn: "1227700086460",
        emails: [
          "dpo@inno.tech"
        ]
      },
      {
        id: "37fe40eb2a72",
        name: "\u0410\u041E \xAB\u041E\u0422\u041F \u0411\u0430\u043D\u043A\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u0410\u041E \xAB\u041E\u0422\u041F \u0411\u0430\u043D\u043A\xBB",
        inn: "7708001614",
        ogrn: "1027739176563",
        emails: [
          "spravka@otpbank.ru"
        ]
      },
      {
        id: "8a6ab74549a6",
        name: "\u041F\u0410\u041E \xAB\u0418\u043D\u0442\u0435\u0440 \u0420\u0410\u041E\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041F\u0410\u041E \xAB\u0418\u043D\u0442\u0435\u0440 \u0420\u0410\u041E\xBB",
        inn: "2320109650",
        ogrn: "1022302933630",
        emails: [
          "office@interrao.ru"
        ]
      },
      {
        id: "209f19a16f49",
        name: "\u041E\u041E\u041E \xAB\u0410\u0441\u0442\u043E\u043D\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0410\u0441\u0442\u043E\u043D\xBB",
        inn: "9715350151",
        ogrn: "1197746397045",
        emails: [
          "info@astondevs.ru"
        ]
      },
      {
        id: "cbb0dbe7c3ef",
        name: "\u041E\u041E\u041E \xAB\u0415\u0413\u0410\u0420 \u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        sourceStatus: "",
        notes: "",
        special: null,
        withdrawalExtra: "",
        legalName: "\u041E\u041E\u041E \xAB\u0415\u0413\u0410\u0420 \u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438\xBB",
        inn: "9718022825",
        ogrn: "1167746777868",
        emails: [
          "info@egartech.ru"
        ]
      }
    ],
    templates: {
      withdrawal: {
        body: "\u042F, {{\u0424\u0418\u041E}}, \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0438 \u0441 \u0447.2 \u0441\u0442.9 \u0424\u0435\u0434\u0435\u0440\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0437\u0430\u043A\u043E\u043D\u0430 \u043E\u0442 27.07.2006 \u0433. \u2116 152-\u0424\u0417 \xAB\u041E \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445\xBB, \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u043C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u043C \u043E\u0442\u0437\u044B\u0432\u0430\u044E \u0441\u0432\u043E\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0435 \u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u0432\u0441\u0435\u0445 \u043C\u043E\u0438\u0445 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0440\u0435\u043A\u0440\u0443\u0442\u0435\u0440\u0430\u043C\u0438, \u0440\u0430\u043D\u0435\u0435 \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0435 {{\u041A\u043E\u043C\u043F\u0430\u043D\u0438\u044F}} (\u0434\u0430\u043B\u0435\u0435 \u2013 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440). \u041A \u0447\u0438\u0441\u043B\u0443 \u0442\u0430\u043A\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C, \u0432 \u0447\u0430\u0441\u0442\u043D\u043E\u0441\u0442\u0438, \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F \u0425\u0430\u043D\u0442\u0444\u043B\u043E\u0443 \u0438 \u0430\u043D\u0430\u043B\u043E\u0433\u0438\u0447\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u043D\u044B\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u044F.\n\n\u041D\u0430 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0438 \u0432\u044B\u0448\u0435\u0438\u0437\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0433\u043E, \u0442\u0440\u0435\u0431\u0443\u044E:\n\n1. \u0421 \u043C\u043E\u043C\u0435\u043D\u0442\u0430 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u0433\u043E \u043E\u0442\u0437\u044B\u0432\u0430 \u043F\u0440\u0435\u043A\u0440\u0430\u0442\u0438\u0442\u044C \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u0432\u0441\u0435\u0445 \u043C\u043E\u0438\u0445 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u0432 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0440\u0435\u043A\u0440\u0443\u0442\u0435\u0440\u0430\u043C\u0438, \u0437\u0430 \u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435\u043C \u0441\u043B\u0443\u0447\u0430\u0435\u0432, \u043A\u043E\u0433\u0434\u0430 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0435\u043D\u0438\u0435 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0434\u043E\u043F\u0443\u0441\u043A\u0430\u0435\u0442\u0441\u044F \u0437\u0430\u043A\u043E\u043D\u043E\u0434\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E\u043C \u0420\u043E\u0441\u0441\u0438\u0439\u0441\u043A\u043E\u0439 \u0424\u0435\u0434\u0435\u0440\u0430\u0446\u0438\u0438 \u0431\u0435\u0437 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F \u0441\u0443\u0431\u044A\u0435\u043A\u0442\u0430.\n\n2. \u0423\u043D\u0438\u0447\u0442\u043E\u0436\u0438\u0442\u044C \u0432\u0441\u0435 \u043C\u043E\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430 \u0432 \u0441\u0440\u043E\u043A, \u043D\u0435 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u044E\u0449\u0438\u0439 30 (\u0422\u0440\u0438\u0434\u0446\u0430\u0442\u0438) \u043A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0445 \u0434\u043D\u0435\u0439 \u0441 \u0434\u0430\u0442\u044B \u043F\u043E\u0441\u0442\u0443\u043F\u043B\u0435\u043D\u0438\u044F \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u0433\u043E \u043E\u0442\u0437\u044B\u0432\u0430.\n\n3. \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 \u043E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u0438\u0441\u044C\u043C\u0430, \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0438 \u0441 \u0434\u0435\u043B\u043E\u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C\u0438 \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0430\u043C\u0438 \u0412\u0430\u0448\u0435\u0439 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438, \u0447\u0442\u043E \u043C\u043E\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u043F\u0435\u0440\u0435\u0434\u0430\u044E\u0442\u0441\u044F \u0442\u0440\u0435\u0442\u044C\u0438\u043C \u043B\u0438\u0446\u0430\u043C \u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u044B \u0438\u0437 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0412\u0430\u0448\u0435\u0439 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0435\u0439 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430.\n\n4. \u041D\u0430\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442 \u043D\u0430 \u043F\u043E\u0447\u0442\u0443: {{Email}}.\n\n\u0417\u0430 \u043D\u0435\u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439 \u0437\u0430\u043A\u043E\u043D\u043E\u0434\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430 \u0420\u043E\u0441\u0441\u0438\u0439\u0441\u043A\u043E\u0439 \u0424\u0435\u0434\u0435\u0440\u0430\u0446\u0438\u0438 \u0432 \u043E\u0431\u043B\u0430\u0441\u0442\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u043F\u0440\u0435\u0434\u0443\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u0430 \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u0438\u0432\u043D\u0430\u044F \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u043F\u043E \u0441\u0442.13.11 \u041A\u043E\u0410\u041F \u0420\u0424.",
        subject: "\u041E\u0442\u0437\u044B\u0432 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F \u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u2014 {{\u0424\u0418\u041E}}"
      },
      inquiry: {
        body: "\u042F, {{\u0424\u0418\u041E}} (\u0434\u0430\u043B\u0435\u0435 \u2013 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C), \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0438 \u0441\u043E \u0441\u0442\u0430\u0442\u044C\u0435\u0439 14 \u0424\u0435\u0434\u0435\u0440\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0437\u0430\u043A\u043E\u043D\u0430 \u043E\u0442 27.07.2006 \u0433. \u2116 152-\u0424\u0417 \xAB\u041E \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445\xBB \u043F\u0440\u043E\u0448\u0443 {{\u041A\u043E\u043C\u043F\u0430\u043D\u0438\u044F}} (\u0434\u0430\u043B\u0435\u0435 \u2013 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440) \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E:\n\n1. \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u0444\u0430\u043A\u0442 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435, \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C;\n\n2. \u043F\u0440\u0430\u0432\u043E\u0432\u044B\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u0446\u0435\u043B\u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435, \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C;\n\n3. \u043F\u0435\u0440\u0435\u0447\u0435\u043D\u044C \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F, \u043E\u0431\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0435\u043C\u044B\u0445 \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435, \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C;\n\n4. \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435, \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430;\n\n5. \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u043C\u044B\u0435 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C \u0441\u043F\u043E\u0441\u043E\u0431\u044B \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435, \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430;\n\n6. \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E \u0441\u0440\u043E\u043A\u0430\u0445 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435, \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435 \u043E \u0441\u0440\u043E\u043A\u0430\u0445 \u0438\u0445 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C;\n\n7. \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E\u0431 \u043E\u0441\u0443\u0449\u0435\u0441\u0442\u0432\u043B\u0435\u043D\u043D\u043E\u0439 \u0438\u043B\u0438 \u043E \u043F\u0440\u0435\u0434\u043F\u043E\u043B\u0430\u0433\u0430\u0435\u043C\u043E\u0439 \u0442\u0440\u0430\u043D\u0441\u0433\u0440\u0430\u043D\u0438\u0447\u043D\u043E\u0439 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445, \u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435, \u0432\u043E \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u0445 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0446\u0435\u043B\u0435\u0439 \u0440\u0435\u043A\u0440\u0443\u0442\u043C\u0435\u043D\u0442\u0430;\n\n8. \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E \u043B\u0438\u0446\u0430\u0445 (\u0437\u0430 \u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435\u043C \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u0432 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u0430), \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0438\u043C\u0435\u044E\u0442 \u0434\u043E\u0441\u0442\u0443\u043F \u043A \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u043C \u0434\u0430\u043D\u043D\u044B\u043C \u0438\u043B\u0438 \u043A\u043E\u0442\u043E\u0440\u044B\u043C \u043C\u043E\u0433\u0443\u0442 \u0431\u044B\u0442\u044C \u0440\u0430\u0441\u043A\u0440\u044B\u0442\u044B \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0438 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430 \u0441 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C \u0438\u043B\u0438 \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0438 \u0424\u0435\u0434\u0435\u0440\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0437\u0430\u043A\u043E\u043D\u0430 \u043E\u0442 27.07.2006 \u0433. \u2116 152-\u0424\u0417 \xAB\u041E \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445\xBB;\n\n9. \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u043B\u0438 \u0444\u0430\u043C\u0438\u043B\u0438\u044E, \u0438\u043C\u044F, \u043E\u0442\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u0430\u0434\u0440\u0435\u0441 (\u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0439 \u0430\u0434\u0440\u0435\u0441 \u0438 \u0430\u0434\u0440\u0435\u0441 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0439 \u043F\u043E\u0447\u0442\u044B) \u043B\u0438\u0446\u0430, \u043E\u0441\u0443\u0449\u0435\u0441\u0442\u0432\u043B\u044F\u044E\u0449\u0435\u0433\u043E \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u043F\u043E \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u044E \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u0430, \u0435\u0441\u043B\u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0430 \u0438\u043B\u0438 \u0431\u0443\u0434\u0435\u0442 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0430 \u0442\u0430\u043A\u043E\u043C\u0443 \u043B\u0438\u0446\u0443;\n\n10. \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u043B\u0438 \u0444\u0430\u043C\u0438\u043B\u0438\u044E, \u0438\u043C\u044F, \u043E\u0442\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u0430\u0434\u0440\u0435\u0441 (\u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0439 \u0430\u0434\u0440\u0435\u0441 \u0438 \u0430\u0434\u0440\u0435\u0441 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0439 \u043F\u043E\u0447\u0442\u044B) \u043B\u0438\u0446\u0430, \u043E\u0441\u0443\u0449\u0435\u0441\u0442\u0432\u043B\u044F\u044E\u0449\u0435\u0433\u043E \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0435 \u0438\u0445 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0438 \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C (\u0432 \u0442\u043E\u043C \u0447\u0438\u0441\u043B\u0435 \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0438 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F);\n\n11. \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E \u0441\u043F\u043E\u0441\u043E\u0431\u0430\u0445 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u043C \u043E\u0431\u044F\u0437\u0430\u043D\u043D\u043E\u0441\u0442\u0435\u0439, \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0442\u044C\u0435\u0439 18.1 \u0424\u0435\u0434\u0435\u0440\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0437\u0430\u043A\u043E\u043D\u0430 \u043E\u0442 27.07.2006 \u0433. \u2116 152-\u0424\u0417 \xAB\u041E \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445\xBB;\n\n12. \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u043E\u0441\u0443\u0449\u0435\u0441\u0442\u0432\u043B\u0435\u043D\u0438\u044F \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u043C \u043F\u0440\u0430\u0432, \u043F\u0440\u0435\u0434\u0443\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043D\u044B\u0445 \u0424\u0435\u0434\u0435\u0440\u0430\u043B\u044C\u043D\u044B\u043C \u0437\u0430\u043A\u043E\u043D\u043E\u043C \u043E\u0442 27.07.2006 \u0433. \u2116 152-\u0424\u0417 \xAB\u041E \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445\xBB.\n\n\u041F\u0440\u043E\u0448\u0443 \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 10 (\u0414\u0435\u0441\u044F\u0442\u0438) \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0434\u043D\u0435\u0439 \u0441\u043E\u043E\u0431\u0449\u0438\u0442\u044C \u043C\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u0443\u044E \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u043F\u043E \u0430\u0434\u0440\u0435\u0441\u0443 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0439 \u043F\u043E\u0447\u0442\u044B:  {{Email}}",
        subject: "\u0417\u0430\u043F\u0440\u043E\u0441 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043E\u0431 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u2014 {{\u0424\u0418\u041E}}"
      }
    },
    sources: [
      {
        file: "\u0421\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0439 \u0434\u043B\u044F \u043E\u0442\u0437\u044B\u0432\u0430 \u041F\u0414.xlsx",
        sha256: "fc88d94ce2c2316993d915178a1a3aeabe2691ae10f60cb023d52a83b50099dd"
      },
      {
        file: "\u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B.xlsx",
        sha256: "4273ff4347d3e3d962de2715bda330fe8f32c878338479f67ec241430d76e12a"
      },
      {
        file: "\u0428\u0430\u0431\u043B\u043E\u043D \u043E\u0442\u0437\u044B\u0432\u0430 \u041F\u0414 \u0443\u043D\u0438\u0432\u0435\u0440\u0441\u0430\u043B\u044C\u043D\u044B\u0439.docx",
        sha256: "83b0e65576c14cd7b58a9ff7accbb8266c0d1490887cf08540aa3e06744bc801"
      },
      {
        file: "\u0428\u0430\u0431\u043B\u043E\u043D_\u0437\u0430\u043F\u0440\u043E\u0441\u0430_\u043D\u0430_\u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435_\u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438,_\u043A\u0430\u0441\u0430\u044E\u0449\u0435\u0439\u0441\u044F_\u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438.docx",
        sha256: "24b1914816ba2af13a1ea7865c37054a29852f243d5d7023064cbce1511b0c62"
      }
    ]
  };

  // src/letters.ts
  var validEmail = (s) => /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(s);
  function validateProfile(p) {
    if (!p.fio.trim() || /[\r\n]/.test(p.fio))
      throw new Error("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0424\u0418\u041E \u043E\u0434\u043D\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u043E\u0439.");
    if (!validEmail(p.email.trim()))
      throw new Error("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 email \u0434\u043B\u044F \u043E\u0442\u0432\u0435\u0442\u0430.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(p.date))
      throw new Error("\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0430\u0442\u0443 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F.");
  }
  function substitute(text, values) {
    const result = text.replace(/\{\{([^{}]+)\}\}/g, (_, key) => {
      if (!(key in values)) throw new Error(`\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043F\u043E\u0434\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0430: ${key}`);
      return values[key];
    });
    if (/\{\{|\}\}|\[[^\]]+\]|_{3,}/.test(result))
      throw new Error("\u0412 \u0448\u0430\u0431\u043B\u043E\u043D\u0435 \u043E\u0441\u0442\u0430\u043B\u0438\u0441\u044C \u043D\u0435\u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u044B\u0435 \u043E\u0431\u043E\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F.");
    return result;
  }
  function makeLetter(c, p, mode, t, interaction = "") {
    validateProfile(p);
    if (!c.emails.length || c.emails.some((e) => !validEmail(e)))
      throw new Error(`\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0430\u0434\u0440\u0435\u0441\u0430: ${c.name}`);
    const values = {
      \u0424\u0418\u041E: p.fio.trim(),
      \u041A\u043E\u043C\u043F\u0430\u043D\u0438\u044F: c.legalName?.trim() || c.name,
      Email: p.email.trim(),
      \u0414\u0430\u0442\u0430: p.date
    };
    const missing = [];
    if (mode === "inquiry" && !interaction.trim())
      missing.push("\u0421\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0438 / \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0435 \u0434\u0430\u043D\u043D\u044B\u0445");
    const requisites = [
      [
        c.inn && `\u0418\u041D\u041D \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438: ${c.inn}`,
        c.ogrn && `\u041E\u0413\u0420\u041D \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438: ${c.ogrn}`
      ].filter(Boolean).join(", ")
    ];
    if (p.inn.trim()) requisites.push(`\u0418\u041D\u041D \u0437\u0430\u044F\u0432\u0438\u0442\u0435\u043B\u044F: ${p.inn.trim()}`);
    const passport = [
      p.series && `\u0441\u0435\u0440\u0438\u044F ${p.series}`,
      p.number && `\u2116 ${p.number}`,
      p.issuer && `\u0432\u044B\u0434\u0430\u043D ${p.issuer}`,
      p.city,
      p.issued
    ].filter(Boolean).join(", ");
    if (passport) requisites.push(`\u041F\u0430\u0441\u043F\u043E\u0440\u0442: ${passport}`);
    if (p.phone.trim()) requisites.push(`\u0422\u0435\u043B\u0435\u0444\u043E\u043D: ${p.phone.trim()}`);
    const title = mode === "withdrawal" ? "\u041E\u0422\u0417\u042B\u0412 \u0421\u041E\u0413\u041B\u0410\u0421\u0418\u042F\n\u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445" : "\u0417\u0410\u041F\u0420\u041E\u0421\n\u043D\u0430 \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438, \u043A\u0430\u0441\u0430\u044E\u0449\u0435\u0439\u0441\u044F \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445";
    const actions = [];
    if (mode === "withdrawal" && c.special === "pdf")
      actions.push(
        "\u041F\u0440\u0438\u043B\u043E\u0436\u0438\u0442\u0435 PDF \u0441 \u043E\u0442\u0437\u044B\u0432\u043E\u043C \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F (\u043F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435 \u0438\u0437 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 \u0431\u0430\u0437\u044B)."
      );
    if (mode === "withdrawal" && c.special === "signature") actions.push(c.notes);
    const body = [
      title,
      requisites.filter(Boolean).join("\n"),
      mode === "inquiry" && interaction.trim() ? `\u0421\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0438 / \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0435 \u0434\u0430\u043D\u043D\u044B\u0445: ${interaction.trim()}` : "",
      substitute(t.body, values),
      mode === "withdrawal" ? c.withdrawalExtra : "",
      `${p.date.split("-").reverse().join(".")}
${values["\u0424\u0418\u041E"]}`
    ].filter(Boolean).join("\n\n");
    const subject = substitute(t.subject, values).trim();
    if (!subject || /[\r\n]/.test(subject) || !t.body.trim())
      throw new Error(
        "\u0422\u0435\u043C\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043E\u0434\u043D\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u043E\u0439, \u0442\u0435\u043A\u0441\u0442 \u043D\u0435 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043F\u0443\u0441\u0442\u044B\u043C."
      );
    return {
      companyId: c.id,
      companyName: c.name,
      to: [...new Set(c.emails)],
      subject,
      body,
      missing,
      actions
    };
  }

  // extension/popup.ts
  var prepared = [];
  var form = document.querySelector("#profile");
  var status = document.querySelector("#status");
  var companies = data_default.companies;
  var selected = /* @__PURE__ */ new Set();
  var list = document.querySelector("#companies");
  for (const company of companies) {
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.onchange = () => {
      if (checkbox.checked) selected.add(company.id);
      else selected.delete(company.id);
    };
    label.append(checkbox, document.createTextNode(" " + company.name));
    list.append(label);
  }
  document.querySelector("#select-all").onclick = () => {
    for (const company of companies) selected.add(company.id);
    for (const checkbox of list.querySelectorAll(
      'input[type="checkbox"]'
    ))
      checkbox.checked = true;
    form.dispatchEvent(new Event("input", { bubbles: true }));
    status.textContent = `\u0412\u044B\u0431\u0440\u0430\u043D\u044B \u0432\u0441\u0435 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438: ${selected.size}. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u044C\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.`;
  };
  document.querySelector("#search").oninput = (event) => {
    const query = event.target.value.toLocaleLowerCase();
    for (const label of list.querySelectorAll("label"))
      label.hidden = !label.textContent.toLocaleLowerCase().includes(query);
  };
  var input = (name) => form.elements.namedItem(name);
  input("date").value = new Date(
    Date.now() - (/* @__PURE__ */ new Date()).getTimezoneOffset() * 6e4
  ).toISOString().slice(0, 10);
  void chrome.storage.local.get("profile").then(({ profile }) => {
    if (profile && typeof profile === "object")
      for (const key of ["fio", "email"]) {
        const value = profile[key];
        if (typeof value === "string") input(key).value = value;
      }
  }).catch(() => {
    status.textContent = "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043F\u0440\u043E\u0444\u0438\u043B\u044C.";
  });
  form.onsubmit = (event) => {
    event.preventDefault();
    prepared = [];
    const preview = document.querySelector("#preview");
    preview.replaceChildren();
    try {
      if (!selected.size) throw new Error("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438.");
      const profile = {
        fio: input("fio").value,
        email: input("email").value,
        date: input("date").value,
        inn: "",
        phone: "",
        series: "",
        number: "",
        issuer: "",
        city: "",
        issued: ""
      };
      const mode = input("mode").value;
      const letters = companies.filter((c) => selected.has(c.id)).map(
        (c) => makeLetter(
          c,
          profile,
          mode,
          data_default.templates[mode],
          input("interaction").value
        )
      );
      prepared = letters;
      for (const letter of letters) {
        const details = document.createElement("details");
        const summary = document.createElement("summary");
        const reasons = manualReasons(letter);
        summary.textContent = letter.companyName + (reasons.length ? " \u2014 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435" : " \u2014 \u0433\u043E\u0442\u043E\u0432\u043E");
        if (reasons.length) details.open = true;
        const text = document.createElement("pre");
        text.textContent = [
          "\u041A\u043E\u043C\u0443: " + letter.to.join(", "),
          letter.subject,
          letter.body,
          ...letter.missing,
          ...letter.actions
        ].join("\n\n");
        details.append(summary, text);
        preview.append(details);
      }
      void chrome.storage.local.set({ profile: { fio: profile.fio, email: profile.email } }).catch(() => {
        status.textContent = "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0440\u043E\u0444\u0438\u043B\u044C.";
      });
      const ready = readyLetters(letters).length;
      status.textContent = `\u0413\u043E\u0442\u043E\u0432\u043E \u043A \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435: ${ready} \u0438\u0437 ${letters.length}. \u0422\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439: ${letters.length - ready}. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.`;
    } catch (error) {
      status.textContent = error instanceof Error ? error.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u044C \u043F\u0438\u0441\u044C\u043C\u0430.";
    }
  };
  form.addEventListener("input", () => {
    prepared = [];
  });
  var mailbox = document.querySelector("#mailbox");
  async function command(message) {
    const result = await chrome.runtime.sendMessage(message);
    if (result.error) throw Error(result.error);
    return result.value;
  }
  async function refreshSessions() {
    const sessions = await command({ type: "sessions" });
    const old = mailbox.value;
    mailbox.replaceChildren();
    for (const session of sessions) {
      const option = new Option(session.email, session.key);
      mailbox.add(option);
    }
    if ([...mailbox.options].some((o) => o.value === old)) mailbox.value = old;
    if (!sessions.length)
      mailbox.add(new Option("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0443\u044E \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Mail.ru", ""));
  }
  function action(id, run) {
    document.querySelector(id).onclick = () => {
      const button = document.querySelector(id);
      if (button.disabled) return;
      button.disabled = true;
      void run().catch((e) => {
        status.textContent = e.message;
      }).finally(() => {
        button.disabled = false;
      });
    };
  }
  action("#connect", refreshSessions);
  action("#send", async () => {
    if (!prepared.length) throw Error("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u044C\u0442\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.");
    if (!mailbox.value) throw Error("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 \u043F\u043E\u0447\u0442\u044B \u0438 \u0441\u043F\u0438\u0441\u043E\u043A \u044F\u0449\u0438\u043A\u043E\u0432.");
    const ready = readyLetters(prepared).length;
    if (!ready)
      throw Error(
        "\u041D\u0435\u0442 \u0433\u043E\u0442\u043E\u0432\u044B\u0445 \u043F\u0438\u0441\u0435\u043C. \u0412 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E, \u0447\u0442\u043E \u043D\u0443\u0436\u043D\u043E \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0438\u043B\u0438 \u043F\u0440\u0438\u043B\u043E\u0436\u0438\u0442\u044C."
      );
    pending = { key: mailbox.value, letters: structuredClone(prepared) };
    confirmationText.textContent = `\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C ${ready} \u043F\u0438\u0441\u0435\u043C \u0441 ${mailbox.selectedOptions[0].text}? \u0422\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u0438 \u043D\u0435 \u0431\u0443\u0434\u0443\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u044B: ${prepared.length - ready}.`;
    confirmation.hidden = false;
    document.querySelector("#confirm-send").focus();
  });
  var confirmation = document.querySelector("#confirmation");
  var confirmationText = document.querySelector("#confirmation-text");
  var pending = null;
  function cancelConfirmation() {
    pending = null;
    confirmation.hidden = true;
  }
  action("#cancel-send", async () => {
    cancelConfirmation();
  });
  mailbox.addEventListener("change", cancelConfirmation);
  form.addEventListener("input", cancelConfirmation);
  form.addEventListener("submit", cancelConfirmation);
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") cancelConfirmation();
  });
  action("#confirm-send", async () => {
    const batch = pending;
    if (!batch) return;
    cancelConfirmation();
    await command({ type: "start", key: batch.key, letters: batch.letters });
    prepared = [];
    status.textContent = "\u041E\u0447\u0435\u0440\u0435\u0434\u044C \u0437\u0430\u043F\u0443\u0449\u0435\u043D\u0430. \u041E\u043A\u043D\u043E \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u043C\u043E\u0436\u043D\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u044C, \u0432\u043A\u043B\u0430\u0434\u043A\u0443 \u043F\u043E\u0447\u0442\u044B \u043E\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0439.";
    await refreshQueue();
  });
  action("#stop", async () => {
    await command({ type: "stop" });
    await refreshQueue();
  });
  action("#resume", async () => {
    await command({ type: "resume", key: mailbox.value });
    await refreshQueue();
  });
  async function refreshQueue() {
    const { queue } = await chrome.storage.local.get("queue");
    const box = document.querySelector("#queue");
    box.replaceChildren();
    if (!queue) return;
    const title = document.createElement("p");
    title.textContent = `${queue.email}: ${queue.running ? "\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430" : "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E"} \xB7 ${queue.items.filter((i) => i.status === "sent").length} / ${queue.items.filter((i) => i.status !== "manual").length} (\u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439: ${queue.items.filter((i) => i.status === "manual").length})`;
    box.append(title);
    if (queue.error) {
      const p = document.createElement("p");
      p.textContent = queue.error;
      box.append(p);
    }
    const labels = {
      manual: "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
      queued: "\u0412 \u043E\u0447\u0435\u0440\u0435\u0434\u0438",
      sending: "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F",
      sent: "\u041F\u0440\u0438\u043D\u044F\u0442\u043E Mail.ru",
      uncertain: "\u041D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u2014 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u0447\u0442\u0443"
    };
    for (const item of queue.items) {
      const row = document.createElement("p");
      row.textContent = item.letter.companyName + ": " + labels[item.status] + (item.reasons?.length ? " \u2014 " + item.reasons.join("; ") : "");
      box.append(row);
    }
  }
  void refreshSessions().catch(() => {
    status.textContent = "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F \u043A \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044E.";
  });
  var refreshing = false;
  async function pollQueue() {
    if (refreshing) return;
    refreshing = true;
    try {
      await refreshQueue();
    } catch {
      status.textContent = "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0443\u0441 \u043E\u0447\u0435\u0440\u0435\u0434\u0438.";
    } finally {
      refreshing = false;
    }
  }
  void pollQueue();
  setInterval(() => void pollQueue(), 1500);
  action("#download-log", async () => {
    const report = await command({ type: "diagnostics" });
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(report, null, 2)], { type: "application/json" })
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "mailru-diagnostics-" + (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-") + ".json";
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
    status.textContent = "\u0416\u0443\u0440\u043D\u0430\u043B \u0441\u043A\u0430\u0447\u0430\u043D. \u0412 \u043D\u0451\u043C \u043D\u0435\u0442 \u0442\u043E\u043A\u0435\u043D\u043E\u0432, \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u0438 \u0442\u0435\u043A\u0441\u0442\u043E\u0432 \u043F\u0438\u0441\u0435\u043C.";
  });
})();
